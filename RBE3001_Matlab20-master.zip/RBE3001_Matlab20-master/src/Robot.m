classdef Robot < handle
    
    properties
        myHIDSimplePacketComs;
        pol; 
        GRIPPER_ID = 1962
        end_points; %represents the end-of-motion data acquired from servo_jp() and interpolate_jp() --> now used for goal_cp()
        velocity;   %represents the joint velocity values
        positions;  %represents the joint position values
        measured_js_data; % data from measured_js() to be sent to measured_cp()
        setpoint_js_data; % data from setpoint_js() to be sent to setpoint_cp()

    end
    
    methods
        
        %returns current joint positions or velocities based on what is
        %requested and sets the rest to zero
        function array = measured_js(packet, GETPOS, GETVEL)    %takes in two booleans --> if true, return respective results
            array = zeros(2, 3, 'single');              %create a 2x3 matrix of zeroes
            if GETPOS == true                           %if we want the position of the motor
                packet.positions = packet.read(1910);   %read the returned position data, the variable position helps it keep it saved
                pos1 = packet.positions(3);             %read motor 1 position and save
                pos2 = packet.positions(5);             %read motor 2 position and save
                pos3 = packet.positions(7);             %read motor 3 position and save
                
                array(1,:) = [ pos1, pos2, pos3 ];      %for the first row and all columns set it = to the positions from above
                packet.measured_js_data = array(1,:);
            end
            
            if GETVEL == true                           %if we want the velocity of the motor
                 packet.velocity = packet.read(1822);   %read the returned velocity data, the variable position helps it keep it saved
                 vel1 = packet.velocity(3);             %read motor 1 velocity and save
                 vel2 = packet.velocity(6);             %read motor 2 velocity and save
                 vel3 = packet.velocity(9);             %read motor 3 velocity and save
                 
                 array(2,:) = [vel1, vel2, vel3];       %for the first row and all columns set it = to the velocities from above
            end      
        end
            
        
        %The is a shutdown function to clear the HID hardware connection
        function  shutdown(packet)
	    %Close the device
            packet.myHIDSimplePacketComs.disconnect();
        end
        
        % Create a packet processor for an HID device with USB PID 0x007
        function packet = Robot(dev)
            packet.myHIDSimplePacketComs=dev; 
            packet.pol = java.lang.Boolean(false);
        end
        
        %Perform a command cycle. This function will take in a command ID
        %and a list of 32 bit floating point numbers and pass them over the
        %HID interface to the device, it will take the response and parse
        %them back into a list of 32 bit floating point numbers as well
        function com = command(packet, idOfCommand, values)
                com= zeros(15, 1, 'single');
                try
                    ds = javaArray('java.lang.Double',length(values));
                    for i=1:length(values)
                        ds(i)= java.lang.Double(values(i));
                    end
                    % Default packet size for HID
                    intid = java.lang.Integer(idOfCommand);
                    packet.myHIDSimplePacketComs.writeFloats(intid,  ds);
                    ret = 	packet.myHIDSimplePacketComs.readFloats(intid) ;
                    for i=1:length(com)
                       com(i)= ret(i).floatValue();
                    end
                catch exception
                    getReport(exception)
                    disp('Command error, reading too fast');
                end
        end
        
        function com = read(packet, idOfCommand)
                com= zeros(15, 1, 'single');
                try

                    % Default packet size for HID
                    intid = java.lang.Integer(idOfCommand);
                    ret = 	packet.myHIDSimplePacketComs.readFloats(intid) ;
                    for i=1:length(com)
                       com(i)= ret(i).floatValue();
                    end
                catch exception
                  getReport(exception)
                    disp('Command error, reading too fast');
                end
        end
        
        function  write(packet, idOfCommand, values)
                try
                    ds = javaArray('java.lang.Double',length(values));
                    for i=1:length(values)
                        ds(i)= java.lang.Double(values(i));
                    end
                    % Default packet size for HID
                    intid = java.lang.Integer(idOfCommand);
                    packet.myHIDSimplePacketComs.writeFloats(intid,  ds,packet.pol);

                catch exception
                    getReport(exception)
                    disp('Command error, reading too fast');
                end
        end
        
        % Specifies a position to the gripper
        function writeGripper(packet, value)
            try
                ds = javaArray('java.lang.Byte',length(1));
                ds(1)= java.lang.Byte(value);
                intid = java.lang.Integer(packet.GRIPPER_ID);
                packet.myHIDSimplePacketComs.writeBytes(intid, ds, packet.pol);
            catch exception
                getReport(exception)
                disp('Command error, reading too fast');
            end
        end
        
        % Opens the gripper
        function openGripper(packet)
            packet.writeGripper(180);
        end
        
        % Closes the gripper
        function closeGripper(packet)
            packet.writeGripper(0);
        end
        
        %Returns a 1x3 array that contains current joint set position in
        %degrees
        function name = setpoint_js(packet)         %returns the variable 'name' which contains the current joint setpoint data
            array = packet.read(1910);              %reads the information at the given address
            name = [array(2), array(4), array(6)];  %sets the relevant addresses to 'name' 
            packet.setpoint_js_data = name;
        end
        
        %Returns a 1x3 array that has the end-of-motion joint setpoint
        %positions in degrees
        function joint_goals = goal_js(packet)      %returns the variable 'joint_goals' which contains the end
            joint_goals = packet.end_points;        %sets the variable equal to the class variable which contains the end-of-motion data acquired from servo_jp() and interpolate_jp()
        end

        %Sends joint values directly to the actuators and bypasses
        %interpolation
        function servo_jp(packet, positions)    %takes in a position vector    
            array = zeros(15, 1, 'single');     %creates a 15x1 matrix of zeroes
            array(3) = positions(1);            %sets the third index of the matrix to the first position vector input
            array(4) = positions(2);            %sets the fourth index of the matrix to the second position vector input
            array(5) = positions(3);            %sets the fifth index of the matrix to the third position vector input
            packet.write(1848, array);          %sends the new matrix to the actuators at the given address
            packet.end_points = [array(3) array(4) array(5)];   %sets the class variable to the position vector inputs for goal_js()
        end
        
        %Sends joint values directly to the actuators but takes
        %interpolation into consideration
        function interpolate_jp(packet, timeAndPoints)  %takes in a time and position vector
            array = zeros(15, 1, 'single');     %creates a 15x1 matrix of zeroes
            array(1) = timeAndPoints(1);        %sets the first index of the matrix to the first time and position vector input (interpolation time)         
            array(2) = 0;                       %sets the second index of the matrix to zero --> interpolation time is linear
            array(3) = timeAndPoints(2);        %sets the third index of the matrix to the second time and position vector input (first position)
            array(4) = timeAndPoints(3);        %sets the fourth index of the matrix to the third time and position vector input (second position)
            array(5) = timeAndPoints(4);        %sets the fifth index of the matrix to the fourth time and position vector input (third position)
            packet.write(1848, array);          %sends the new matrix to the actuators at the given address
            packet.end_points = [array(3) array(4) array(5)];   %sets the class variable to the position vector inputs for goal_js()
        end
        
        %Takes in a DH row and returns the corresponding 4x4 homogeneous
        %transformation matrix
        %The method is being hard coded the 4x4 homogeneous transformation
        %matrix and plugging in the parameter input to their respective
        %locations
        function transform = dh2mat(packet, links) %links is a 1x4 matrix input representing the DH row (theta, d, a, alpha) in that order
            transform = zeros(4, 4, 'single'); 
            
            transform(1,1) = cosd(links(1));
            transform(2,1) = sind(links(1));
            
            transform(1,2) = -sind(links(1)) * cosd(links(4));
            transform(2,2) = cosd(links(1)) * cosd(links(4));
            transform(3,2) = sind(links(4));
            
            transform(1,3) = sind(links(1)) * sind(links(4));
            transform(2,3) = -cosd(links(1)) * sind(links(4));
            transform(3,3) = cosd(links(4));
            
            transform(1,4) = links(3) * cosd(links(1));
            transform(2,4) = links(3) * sind(links(1));
            transform(3,4) = links(2);
            transform(4,4) = 1;          
        end 
            
        %Takes in the entire DH table and returns the corresponding 4x4
        %homogeneous transformation matrix for the composite transformation 
        function compTransform = dh2fk(packet, links)   
            composite = eye(4,4);
            n = size(links,1);
            for i = 1:n 
                theta = links(i,1); %multiplies the thetas by each other
                d = links(i,2); %multiplies the d's by each other
                a = links(i,3); %multiplies the a's by each other
                alpha = links(i,4); %multiplies the alphas by each other
                
                intermediate = packet.dh2mat([theta d a alpha]); %performs dh2mat() on the each DH parameter to return a 4x4 homogeneous transformation matrix
                composite = composite * intermediate; %multiplies each returned 4x4 homogeneous transformation matrix by each other to get the composite transformation
            end     
            
            compTransform = composite;
        end
        
        %Takes in three joint angles and returns the corresponding 4x4
        %homogeneous transformation matrix relative to our arm
        function fkTransform = fk3001(packet, n)
             DHTable = [ 0, 55, 0, 0; n(1), 40, 0, -90; n(2) - 90, 0, 100, 0; n(3) + 90, 0, 100, 0 ]; %hard coding in the DH table
             fkTransform = packet.dh2fk(DHTable); %gets and returns the composite transformation
        end
        
        %Returns the corresponding 4x4 homogeneous transformation matrix
        %based on the returned values from measured_js()
        function joint_pos = measured_cp(packet)
            joint_pos = packet.fk3001(packet.measured_js_data);
        end
        
        %Returns the corresponding 4x4 homogeneous transformation matrix
        %based on the returned values from setpoint_js()
        function setpoint = setpoint_cp(packet)
            setpoint = packet.fk3001(packet.setpoint_js_data);
        end
        
        %Returns the corresponding 4x4 homogeneous transformation matrix
        %based on the returned values from goal_cp()
        function endpoint = goal_cp(packet)
            endpoint = packet.fk3001(packet.end_points);
        end
        
        %Takes in three joint angles and returns the four 4x4 homogeneous
        %transformation matrices from frames 01, 02, 03, and 04 as a 4x16
        %matrix
        function [FK] = DHkine(packet,j)
            %hard coding in the transformation matrix for frame 01
            T01 = [1, 0, 0, 0; 0, 1, 0, 0; 0, 0, 1, 55; 0, 0, 0, 1]; 
            
            %coding in the DH row(with input parameter) for frames 12, 23, and 34 and finding the
            %corresponding 4x4 homogeneous tranformation matrix through
            %dh2mat()
            T12 = packet.dh2mat([j(1), 40, 0, -90]); 
            T23 = packet.dh2mat([j(2) - 90, 0, 100, 0]);
            T34 = packet.dh2mat([j(3) + 90, 0, 100, 0]);
            
            %multiplying the respective frames together to achieve the
            %final transformation matrices
            T02 = T01*T12;
            T03 = T02*T23;
            T04 = T03*T34;
            
            %returning the four 4x4 homogeneous transformation matrices
            %combined as a 4x16 matrix
            FK = [T01 T02 T03 T04];
        end

        %takes in the combined 4x16 matrix previously found and returns the
        %position vectors of the end effector as a matrix
        function [Q] = XYZkine(packet,FK)
            Q1=[0 FK(1,4) FK(1,8) FK(1,12) FK(1,16)]; %stores the fourth columns in the first row (x positions)
            Q2=[0 FK(2,4) FK(2,8) FK(2,12) FK(2,16)]; %stores the fourth columns in the second row (y positions)
            Q3=[0 FK(3,4) FK(3,8) FK(3,12) FK(3,16)]; %stores the fourth columns in the third row (z positions)
            Q=[Q1;Q2;Q3];
        end 
        
        %takes in a 3x1 vector position vector in task space as the input
        %and returns the corresponding joint angles that the robot's EE
        %would make to move to that target position
        function jointMatrix = ik3001(packet,positions) %jointMatrix = [q1,q2,q3], positions = [x,y,z]
            
            %performs the inverse kinematics using the geometric method
            x = positions(1,1);
            y = positions(2,1);
            z = positions(3,1);
            
            d1 = 95;
            a1 = 100;
            a2 = 100;
            
            r = sqrt(x^2 + y^2);
            s = z - d1;
            
            D3 = -((((a1)^2) + ((a2)^2) - ((r^2) + (s^2)))/(2*a1*a2));
            C3 = sqrt(1-((D3)^2));
            D2 = (((a1^2) + (r^2) + (s^2) - (a2^2))/(2 * a1*(sqrt((r^2) + (s^2)))));
            C2 = -((sqrt(1-((D2)^2))));
            D1 = x/r;
            
            alpha2 = atan2d(s,r);
            beta2 = atan2d(C2,D2);
            
            theta3 = atan2d(C3,D3) - 90;
            theta2 = 90 - (alpha2 - (beta2));
            theta1 = atan2d(y,x);
            
            %catches out of bounds errors 
%             if(((theta1 < 90) && (theta1 > -90)) || ((theta2 < 100) && (theta2 > -45)) || ((theta3 < 63) && (theta3 > -90)))
%                 error('Angles must be in the Task Space')
%             end
            
            jointMatrix = [theta1, theta2, theta3]; %stores the outputted joint angles in jointMatrix    
            
        end
        
        %takes in the current joint angles and returns the corresponding
        %upper half 6x3 Jacobian matrix representing linear velocities
        function jacobMatrix = jacob3001(packet, q)
            
            %takes in three joint angles in an array and separates them
            %into three different variables
            theta1 = q(1);
            theta2 = q(2);
            theta3 = q(3);
            
            %performs the Jacobian math within the matrix
            jacobMatrix =   [
                            -100*sin(theta1)*(cos(theta2-90)+cos(theta2+theta3)) -100*cos(theta1)*(sin(theta2-90)+sin(theta2+theta3)) -100*cos(theta1)*(sin(theta2-90)+sin(theta2+theta3));
                            100*cos(theta1)*(cos(theta2-90)+cos(theta2+theta3)) -100*sin(theta1)*(sin(theta2-90)+sin(theta2+theta3)) -100*sin(theta2+theta3)*sin(theta1);
                            0 -100*cos(theta2-90)-100*cos(theta2+theta3) -100*cos(theta2+theta3);
                            0 -sin(theta1) -sin(theta1);
                            0 cos(theta1) cos(theta1);
                            1 0 0
                            ];    
               
        end
        
        %solves for the determinant of the Jacobian matrix after turning it
        %into a 3x3 matrix 
        function determinant = det3001(packet, q)
            
            theta1 = q(1);
            theta2 = q(2);
            theta3 = q(3);
            
            %takes the relevant components from the Jacobian and places
            %them into a 3x3 matrix
            detMatrix = [
                        -100*sin(theta1)*(cos(theta2-90)+cos(theta2+theta3)) -100*cos(theta1)*(sin(theta2-90)+sin(theta2+theta3)) -100*cos(theta1)*(sin(theta2-90)+sin(theta2+theta3));
                        100*cos(theta1)*(cos(theta2-90)+cos(theta2+theta3)) -100*sin(theta1)*(sin(theta2-90)+sin(theta2+theta3)) -100*sin(theta2+theta3)*sin(theta1);
                        0 -100*cos(theta2-90)-100*cos(theta2+theta3) -100*cos(theta2+theta3);
                        ];
                    
            %solves for the determinant of the matrix above        
            determinant = det(detMatrix);
            
            %if the determinant is between -200 and 200, move the robot to
            %a non-singularity position and throw out an error
            if det(detMatrix) < 200 && det(detMatrix) > -200 
               packet.servo_jp([60 60 60]); 
               pause(0.5);
               packet.shutdown();
               error('approaching a singularity')
            end  
            
        end
        
        %takes in the current joint angles and velocities and returns the
        %6x1 vector of linear and angular velocities
        function finalMatrix = fdk3001(packet, q, v)
            
            %inputs the current joint angles into jacob3001 and sets it
            %equal to jacobMatrix
            jacobMatrix = packet.jacob3001(q);
            
            velMatrix = [v(1); v(2); v(3)];
            
            %multiplies the Jacobian matrix by the velocities
            finalMatrix = jacobMatrix * velMatrix;
            
        end
        
        
        
    end
        
end
