clear
clear java
clear classes;

vid = hex2dec('16c0');
pid = hex2dec('0486');

disp (vid);
disp (pid);

javaaddpath ../lib/SimplePacketComsJavaFat-0.6.4.jar;
import edu.wpi.SimplePacketComs.*;
import edu.wpi.SimplePacketComs.device.*;
import edu.wpi.SimplePacketComs.phy.*;
import java.util.*;
import org.hid4java.*;
version -java
myHIDSimplePacketComs=HIDfactory.get();
myHIDSimplePacketComs.setPid(pid);
myHIDSimplePacketComs.setVid(vid);
myHIDSimplePacketComs.connect();

% Create a PacketProcessor object to send data to the nucleo firmware
pp = Robot(myHIDSimplePacketComs); 
model = Model(myHIDSimplePacketComs); 

% Passive --> store the data from measured_js(), grab the relevant position
% values, and input them into plot_arm()
while(1)
   pp.measured_js(true,false) 
   points = pp.measured_js(true,false); 
   points = points(1,:);
   model.plot_arm(points);
end


% Active --> sends to five values and repeats the process from "passive"
% but runs each step for 5 seconds (taking interpolation time into account)
% pp.interpolate_jp([2000 0 0 0]);
% tic
% while(toc < 5)
%    pp.measured_js(true,false);
%    disp(pp.fk3001([0 0 0]))
%    points = pp.measured_js(true,false);
%    points = points(1,:);
%    model.plot_arm(points);
%    toc
% end
% pause(2);

% pp.interpolate_jp([2000 20 20 20]);
% tic
% while(toc < 5)
%    pp.measured_js(true,false);
%    disp(pp.fk3001([20 20 20]))
%    points = pp.measured_js(true,false);
%    points = points(1,:);
%    model.plot_arm(points);
%    toc
% end
% pause(2);

% pp.interpolate_jp([2000 30 30 30]);
% tic
% while(toc < 5)
%    pp.measured_js(true,false);
%    disp(pp.fk3001([30 30 30]))
%    points = pp.measured_js(true,false);
%    points = points(1,:);
%    model.plot_arm(points);
%    toc
% end
% pause(2);

% pp.interpolate_jp([2000 40 40 40]);
% tic       
% while(toc < 5)
%    pp.measured_js(true,false);
%    disp(pp.fk3001([40 40 40]))
%    points = pp.measured_js(true,false);
%    points = points(1,:);
%    model.plot_arm(points);
%    toc
% end
% pause(2);

% pp.interpolate_jp([2000 50 50 50]);
% tic
% while(toc < 5)
%    pp.measured_js(true,false);
%    disp(pp.fk3001([50 50 50]))
%    points = pp.measured_js(true,false);
%    points = points(1,:);
%    model.plot_arm(points);
%    toc
% end


% % Triangle
% 
% %Time values array
% time = zeros(10000,1);
% 
% %Joint angles array
% joint1 = zeros(10000,1);
% joint2 = zeros(10000,1);
% joint3 = zeros(10000,1);
% 
% %End effector position array
% xpos = zeros(10000,1);
% ypos = zeros(10000,1);
% zpos = zeros(10000,1);
% 
% %Start arm at the zero position
% pp.interpolate_jp([1000 0 0 0]);
% pause(2);
% 
% %Start the timer and store it
% initial_time = tic;
% 
% %Send the arm to the first triangle position
% pp.interpolate_jp([2000 0 65 -35]);
% for i = 1:1200 %Iterate through the loop enough times to gather data while taking the 2000ms interpolation time into account
%    
%    %Grabs the position values
%    angles = pp.measured_js(true,false); %grab the angle values
%    joint1(i) = angles(1,1); %grab the relevant angle values (first row and x)
%    joint2(i) = angles(1,2); %grab the relevant angle values (first row and y)
%    joint3(i) = angles(1,3); %grab the relevant angle values (first row and z)
%    
%    %Grabs the transformation matrix 
%    pos = pp.measured_cp();
%     
%    xpos(i) = pos(1,4); %grab the relevant position values values (first row, fourth column, and x)
%    ypos(i) = pos(2,4); %grab the relevant position values values (second row, fourth column, and y)
%    zpos(i) = pos(3,4); %grab the relevant position values values (second row, fourth column, and z)
%    
%    %Resets the timer
%    time(i) = tic - initial_time;
% end
% 
% pause(3); 
% 
% %Send the arm to the second triangle position
% pp.interpolate_jp([2000 0 80 35]);
% for i = 1201:2400
%    angles = pp.measured_js(true,false);
%    joint1(i) = angles(1,1);
%    joint2(i) = angles(1,2);
%    joint3(i) = angles(1,3);
%    
%    pos = pp.measured_cp();
% 
%    xpos(i) = pos(1,4);
%    ypos(i) = pos(2,4);
%    zpos(i) = pos(3,4);
%    
%    time(i) = tic - initial_time;
%    
% end
% 
% pause(3);
% 
% %Send the arm to the third triangle position (zero position)
% pp.interpolate_jp([2000 0 0 0]);
% for i = 2401:10000
%    angles = pp.measured_js(true,false);
%    joint1(i) = angles(1,1);
%    joint2(i) = angles(1,2);
%    joint3(i) = angles(1,3);
%    
%    pos = pp.measured_cp();
% 
%    xpos(i) = pos(1,4);
%    ypos(i) = pos(2,4);
%    zpos(i) = pos(3,4);
%    
%    time(i) = tic - initial_time;
% end
% 
% %Plots the data into four different figures
% figure(1)
% plot(time,joint1,"-b");
% hold on; 
% plot(time,joint2,"-r");
% plot(time,joint3,"-g");
% title("Joint Angles vs Time");
% xlabel("Time(ms)");
% ylabel("Joint Angle(deg)");
% legend("Joint 1","Joint 2","Joint 3");
% 
% figure(2)
% plot(time,xpos,"-b");
% hold on;
% plot(time,zpos,"-r");
% title("X and Z Position vs Time");
% xlabel("Time(ms)");
% ylabel("Position(mm)");
% legend("X Position","Z Position");
% 
% figure(3)
% plot(xpos,zpos,"-b");
% hold on;
% plot(58,21,"Og",'MarkerSize',10);
% plot(177,86,"Og",'MarkerSize',10);
% plot(99,195,"Og",'MarkerSize',10);
% title("Tip Position in the X Z Plane");
% xlabel("X Position (mm)");
% ylabel("Z Position (mm)");
% legend("Tip Position");
% 
% figure(4)
% plot(xpos,ypos,"-b");
% hold on;
% plot(58,0,"Og",'MarkerSize',10);
% plot(177,0,"Og",'MarkerSize',10);
% plot(99,0,"Og",'MarkerSize',10);
% title("Tip Position in the X Y Plane");
% xlabel("X Position (mm)");
% ylabel("Y Position (mm)");
% legend("Tip Position");
% axis([0 200 -100 200]);
