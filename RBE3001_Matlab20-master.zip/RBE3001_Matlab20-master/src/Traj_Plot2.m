clear
clear java
clear classes;

vid = hex2dec('16c0');
pid = hex2dec('0486');

disp (vid);
disp (pid);

javaaddpath ../lib/SimplePacketComsJavaFat-0.6.4.jar;
import edu.wpi.SimplePacketComs.*;
import edu.wpi.SimplePacketComs.device.*;
import edu.wpi.SimplePacketComs.phy.*;
import java.util.*;
import org.hid4java.*;
version -java
myHIDSimplePacketComs=HIDfactory.get();
myHIDSimplePacketComs.setPid(pid);
myHIDSimplePacketComs.setVid(vid);
myHIDSimplePacketComs.connect();

% Create a PacketProcessor object to send data to the nucleo firmware
pp = Robot(myHIDSimplePacketComs); 
model = Model(myHIDSimplePacketComs); 
traj = Traj_Planner(myHIDSimplePacketComs);

%Start arm at the first position
pp.servo_jp([-7.2532 81.3235 34.4058]);

pause(2);

%Joint angles array
joint1 = zeros(10000,1);
joint2 = zeros(10000,1);
joint3 = zeros(10000,1);

%End effector position array
xpos = zeros(10000,1);
ypos = zeros(10000,1);
zpos = zeros(10000,1);

%finds the four cubic coefficients of each joint
q1 = traj.cubic_traj(0, 2, -7.2532, 48.0128, 0, 0);
q2 = traj.cubic_traj(0, 2, 81.3235, 20.4600, 0, 0);
q3 = traj.cubic_traj(0, 2, 34.4058, 22.9265, 0, 0);

offset = 0;

tic;

i = 1;

%angle data array
angles_data = zeros(1,3);

%velocity data array
velocity_data = zeros(1,3);

while toc < 2 
    
    %finds the current joint angle 
    q1_out = traj.cubic_output(toc, q1);
    q2_out = traj.cubic_output(toc, q2);
    q3_out = traj.cubic_output(toc, q3);
    
    %finds the current joint velocity
    q1_out_vel = traj.vel_cubic_output(toc,q1);
    q2_out_vel = traj.vel_cubic_output(toc,q2);
    q3_out_vel = traj.vel_cubic_output(toc,q3);
    
    %finds the current joint acceleration
    q1_out_acc = traj.acc_cubic_output(toc,q1);
    q2_out_acc = traj.acc_cubic_output(toc,q2);
    q3_out_acc = traj.acc_cubic_output(toc,q3);
    
    %Send the arm to the second triangle position
    pp.servo_jp([q1_out q2_out q3_out]);

    angles = pp.measured_js(true,false); %grab the angle values

    velocities = pp.measured_js(false,true); %grab the velocity values
  
    pos = pp.measured_cp(); %grab the transformation matrix
    
    %store the relevant data in an array
    data = [toc angles(1,1) angles(1,2) angles(1,3) velocities(2,1) velocities(2,2) velocities(2,3) pos(1,4) pos(2,4) pos(3,4) q1_out_vel q2_out_vel q3_out_vel q1_out_acc q2_out_acc q3_out_acc];
    
    %write the array to a csv and append the data
    writematrix(data, 'traj.csv','WriteMode','append');
    
    i = i + 1;
    
end

offset = toc;

tic;

q4 = traj.cubic_traj(0, 2, 48.0128, 0, 0, 0);
q5 = traj.cubic_traj(0, 2, 20.4600, 0, 0, 0);
q6 = traj.cubic_traj(0, 2, 22.9265, 0, 0, 0);

while toc < 2
    
    q4_out = traj.cubic_output(toc, q4);
    q5_out = traj.cubic_output(toc, q5);
    q6_out = traj.cubic_output(toc, q6);
    
    q4_out_vel = traj.vel_cubic_output(toc,q4);
    q5_out_vel = traj.vel_cubic_output(toc,q5);
    q6_out_vel = traj.vel_cubic_output(toc,q6);
    
    q4_out_acc = traj.acc_cubic_output(toc,q4);
    q5_out_acc = traj.acc_cubic_output(toc,q5);
    q6_out_acc = traj.acc_cubic_output(toc,q6);

    %Send the arm to the third triangle position
    pp.servo_jp([q4_out q5_out q6_out]);
    
    angles = pp.measured_js(true,false);

   
    velocities = pp.measured_js(false,true); %grab the angle values

    pos = pp.measured_cp();
    
    data = [(toc+offset) angles(1,1) angles(1,2) angles(1,3) velocities(2,1) velocities(2,2) velocities(2,3) pos(1,4) pos(2,4) pos(3,4) q4_out_vel q5_out_vel q6_out_vel q4_out_acc q5_out_acc q6_out_acc];
    
    writematrix(data, 'traj.csv','WriteMode','append');

    i = i + 1;
    
end

offset = toc + offset;

tic;

q7 = traj.cubic_traj(0, 2, 0, -7.2532, 0, 0);
q8 = traj.cubic_traj(0, 2, 0, 81.3235, 0, 0);
q9 = traj.cubic_traj(0, 2, 0, 34.4058, 0, 0);

while toc < 2  
    
    q7_out = traj.cubic_output(toc, q7);
    q8_out = traj.cubic_output(toc, q8);
    q9_out = traj.cubic_output(toc, q9);
    
    q7_out_vel = traj.vel_cubic_output(toc,q7);
    q8_out_vel = traj.vel_cubic_output(toc,q8);
    q9_out_vel = traj.vel_cubic_output(toc,q9);
    
    q7_out_acc = traj.acc_cubic_output(toc,q7);
    q8_out_acc = traj.acc_cubic_output(toc,q8);
    q9_out_acc = traj.acc_cubic_output(toc,q9);

    %Send the arm to the first triangle position
    pp.servo_jp([q7_out q8_out q9_out]);
        
    angles = pp.measured_js(true,false);
   
    velocities = pp.measured_js(false,true); 
  
    pos = pp.measured_cp();

    data = [(toc+offset) angles(1,1) angles(1,2) angles(1,3) velocities(2,1) velocities(2,2) velocities(2,3) pos(1,4) pos(2,4) pos(3,4) q7_out_vel q8_out_vel q9_out_vel q7_out_acc q8_out_acc q9_out_acc];
    
    writematrix(data, 'traj.csv','WriteMode','append');
   
    i = i + 1;
    
end

%read the csv file storing the relevant data and assign the first column to
%the time variable
joint_data_com = csvread('traj.csv');
time = joint_data_com(:,1);

%Joint Angles vs Time in degrees
figure(1)
plot(time,joint_data_com(:,2),"-b");
hold on; 
plot(time,joint_data_com(:,3),"-r");
plot(time,joint_data_com(:,4),"-g");
title("Joint Angles vs Time");
xlabel("Time(s)");
ylabel("Joint Angle(deg)");
legend("Joint 1","Joint 2","Joint 3");

%XYZ Position vs Time in mm
figure(2)
plot(time,joint_data_com(:,8),"-b");
hold on;
plot(time,joint_data_com(:,9),"-r");
plot(time,joint_data_com(:,10),"-g");
title("X, Y, and Z Position vs Time");
xlabel("Time(s)");  
ylabel("Position(mm)");
legend("X Position","Y Position","Z Position");

%XYZ Tip Position in mm
figure(3)
plot3(joint_data_com(:,8),joint_data_com(:,9),joint_data_com(:,10),"-b");
title("Tip Position Plot");
xlabel("X Position (mm)");
ylabel("Y Position (mm)");
zlabel("Z Position (mm)");
legend("Tip Position");

%Velocities vs Time in deg/s
figure(4)
plot(time,joint_data_com(:,5),"-b");
hold on; 
plot(time,joint_data_com(:,6),"-r");
plot(time,joint_data_com(:,7),"-g");
title("Velocities vs Time");
xlabel("Time(s)");
ylabel("Velocity(deg/s)");
legend("Joint 1","Joint 2","Joint 3");

%Velocities vs Time in mm/s
figure(5)
plot(time,joint_data_com(:,11));
hold on
plot(time,joint_data_com(:,12));
plot(time,joint_data_com(:,13));
title("Velocities vs Time");
xlabel("Time(s)");
ylabel("Velocity(mm/s)");
legend("Joint 1","Joint 2","Joint 3");

%Acceleration vs Time in mm/s^2
figure(6)
plot(time,joint_data_com(:,14));
hold on
plot(time,joint_data_com(:,15));
plot(time,joint_data_com(:,16));
title("Acceleration vs Time");
xlabel("Time(s)");
ylabel("Acceleration(mm/s^2)");
legend("Joint 1","Joint 2","Joint 3");