clear
clear java
clear classes;

vid = hex2dec('16c0');
pid = hex2dec('0486');

disp (vid);
disp (pid);

javaaddpath ../lib/SimplePacketComsJavaFat-0.6.4.jar;
import edu.wpi.SimplePacketComs.*;
import edu.wpi.SimplePacketComs.device.*;
import edu.wpi.SimplePacketComs.phy.*;
import java.util.*;
Array = [points positions time];
timeArray = [];
writematrix(pointsArray,"lab2_plot2.csv")
import org.hid4java.*;
version -java
myHIDSimplePacketComs=HIDfactory.get();
myHIDSimplePacketComs.setPid(pid);
myHIDSimplePacketComs.setVid(vid);
myHIDSimplePacketComs.connect();

% Create a PacketProcessor object to send data to the nucleo firmware
pp = Robot(myHIDSimplePacketComs); 

position = zeros(9000, 3, 'single');    %creates a 9000x3 matrix of zeroes representing position values
time = zeros(9000, 1, 'single');        %creates a 9000x1 matrix of zeroes representing time values

pp.servo_jp([0,0,0]);                   %sets arm to the zero position

pause(3);                               %wait for 3 seconds to acquire accurate data

timeMatrix = [0];                       %creates a matrix of zeroes
tic                                     %starts the timer

pp.interpolate_jp([2500,45,0,0]);          %set the base joint to 45 degrees with 2500 ms interpolation time
%pp.servo_jp([45,0,0]);                     %no interpolation time

for i = 1:9000                          %iterate through a loop 9000 times
   
    positionMatrix = pp.measured_js(true,false);    %set a position matrix equal to the current joint position measurements
    position(i, :) = positionMatrix(1,:);           %grab only the top row (of position values) and insert it into the iterated row to fill the matrix with position values
    time(i, :) = timeMatrix;                        %set the iterated row of the time matrix equal to the matrix that will collect the time stamps
    timeMatrix = toc;                               %have the matrix of time values collect the timestamp in ms
    
end

position = [position,time];             %concatenate the position values matrix with the time values matrix by column                         
writematrix(position,"results.csv")     %send the new matrix into a .csv file

Array=csvread('results.csv');           %throws the .csv file into a new variable 'Array'
hold on                                 %allows us to plot multiple lines on the figure
colTime = Array(:, 4);                  %grabs time data
col1 = Array(:, 1);                     %grabs position joint 1 data
col2 = Array(:, 2);                     %grabs position joint 2 data
col3 = Array(:, 3);                     %grabs position joint 3 data
figure(1)                               %ensures the following graph gets labeled as Figure 1

plot(colTime, col1)                     %plots joint 1 data with respect to time
plot(colTime, col2)                     %plots joint 2 data with respect to time
plot(colTime, col3)                     %plots joint 3 data with respect to time
title("Motor Angle vs Time")            %makes the title             
legend("Motor 1", "Motor 2", "Motor 3");%makes the legend
ylabel("Angle (deg)")                   %labels the y-axis
xlabel("Time (sec)")                    %labels the x-axis
hold off                                %makes sure the next set of data won't be plotted on Figure 1
figure(2)                               %ensures the following graph gets labeled as Figure 2
histogram(colTime)                      %generates a histogram based on timing data
title("Timesteps")                      %makes a title
legend("Timesteps");                    %makes a legend       
ylabel("Frequency")                     %labels the y-axis
xlabel("Time(ms)")                      %labels the x-axis

