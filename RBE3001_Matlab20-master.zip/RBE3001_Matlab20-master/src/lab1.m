%%
% RBE3001 - Laboratory 1 
% 
% Instructions
% ------------
% Welcome again! This MATLAB script is your starting point for Lab
% 1 of RBE3001. The sample code below demonstrates how to establish
% communication between this script and the Nucleo firmware, send
% setpoint commands and receive sensor data.
% 
% IMPORTANT - understanding the code below requires being familiar
% with the Nucleo firmware. Read that code first.

% Lines 15-37 perform necessary library initializations. You can skip reading
% to line 38.
clear
clear java
clear classes;

vid = hex2dec('16c0');
pid = hex2dec('0486');

disp (vid);
disp (pid);

javaaddpath ../lib/SimplePacketComsJavaFat-0.6.4.jar;
import edu.wpi.SimplePacketComs.*;
import edu.wpi.SimplePacketComs.device.*;
import edu.wpi.SimplePacketComs.phy.*;
import java.util.*;
import org.hid4java.*;
version -java
myHIDSimplePacketComs=HIDfactory.get();
myHIDSimplePacketComs.setPid(pid);
myHIDSimplePacketComs.setVid(vid);
myHIDSimplePacketComs.connect();

% Create a PacketProcessor object to send data to the nucleo firmware
pp = Robot(myHIDSimplePacketComs); 
try
  SERV_ID = 1848;            % we will be talking to server ID 1848 on
                           % the Nucleo
  SERVER_ID_READ =1910;% ID of the read packet
  DEBUG   = true;          % enables/disables debug prints

  % Instantiate a packet - the following instruction allocates 60
  % bytes for this purpose. Recall that the HID interface supports
  % packet sizes up to 64 bytes.
  packet = zeros(15, 1, 'single');

  % The following code generates a sinusoidal trajectory to be
  % executed on joint 1 of the arm and iteratively sends the list of
  % setpoints to the Nucleo firmware. 
  viaPts = [0,30,60];

  for k = viaPts
      tic
      packet = zeros(15, 1, 'single');
      packet(1) = 0;%one second time
      packet(2) = 0;%linear interpolation
      packet(3) = k;% First link default set to 'k' to move joint 1 (base joint)
      packet(4) = k;% Second link to 0 -- Set packet(4) to 'k' to move joint 2
      packet(5) = k;% Third link to 0 -- Set packet(5) to 'k' to move joint 3
      
     

      % Send packet to the server and get the response      
      %pp.write sends a 15 float packet to the micro controller
       pp.write(SERV_ID, packet); 
       %positions = pp.measured_js(true,false);
       %pp.read reads a returned 15 float backet from the micro controller.
       returnPacket = pp.read(SERVER_ID_READ);
      toc

      if DEBUG
          disp('Sent Packet:')
          disp(packet);
          disp('Received Packet:');
          disp(returnPacket);
      end
      
      toc
      pause(1) 
      
  end
  

  pp.servo_jp([20, 40, 60]);                %call servo_jp()
  pause(0.5);                               %set pause before measurements to wait before collecting data
  %pp.interpolate_jp([1000, 30, 60, 90]);   %call interpolate_jp()
  pp.measured_js(true, false);                %call measured_js() and find pos and vel
  pp.setpoint_js();                          %call setpoint_js()
  pp.goal_js();                              %call goal_js()
  
  
  % Closes then opens the gripper
  pp.closeGripper()
  pause(1)
  pp.openGripper()
  
catch exception
    getReport(exception)
    disp('Exited on error, clean shutdown');
end

% Clear up memory upon termination
pp.shutdown()

toc
