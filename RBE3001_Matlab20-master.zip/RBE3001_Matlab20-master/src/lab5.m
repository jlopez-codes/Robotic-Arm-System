%%
% RBE 3001 Lab 5 example code!
% Developed by Alex Tacescu (https://alextac.com)
%% comment out clc, clear, and clear java
% clc;
% clear;
% clear java;
format short

%% Flags
DEBUG = false;
STICKMODEL = false;
DEBUG_CAM = false;

%% Setup
vid = hex2dec('16c0');
pid = hex2dec('0486');

if DEBUG
    disp(vid);
    disp(pid);
end

javaaddpath ../lib/SimplePacketComsJavaFat-0.6.4.jar;
import edu.wpi.SimplePacketComs.*;
import edu.wpi.SimplePacketComs.device.*;
import edu.wpi.SimplePacketComs.phy.*;
import java.util.*;
import org.hid4java.*;
version -java;
myHIDSimplePacketComs=HIDfactory.get();
myHIDSimplePacketComs.setPid(pid);
myHIDSimplePacketComs.setVid(vid);
myHIDSimplePacketComs.connect();

robot = Robot(myHIDSimplePacketComs);

% comment out both below after calibration
% cam = Camera();
% cam.DEBUG = DEBUG_CAM;

%% Place Poses per color
purple_place = [150, -50, 11];
green_place = [150, 50, 11];
pink_place = [75, -125, 11];
yellow_place = [75, 125, 11];

%% Main Loop
try
    %Setup camera;
    if cam.params == 0
        error("No camera parameters found!");
    end
     
% executes an infinite loop
while(1)
    
    % Red Ball
    ballImage = snapshot(cam.cam); % takes a distorted image of the space and saves it to a variable
    [bwRed, ignore] = createRedMask(ballImage); % applies a mask over the image using create<Color>Mask() and saves it to an array with two image variables
    [redCenters, redRadii] = imfindcircles(bwRed, [20 60]); % uses imfindcircles to detect circles over the BW masked image with an estimated radius range and saves it to an array
    
    % if the array of centers is not empty (centers of circles were
    % detected in camera space
    if (not(isempty(redCenters))) 
        
        % perform the sign-off #2 operations to convert from camera space
        % to robot space
        notExactRedCenters = getBallCenters(cam, redCenters);
        
        % correct the error in robot space using getExactCenters() on the robot space centers with error 
        exactRedCenters = getExactCenters(cam, notExactRedCenters);
        
        % create a position at the ball centroid raising the z position by
        % 100 to be above the ball
        above = exactRedCenters;
        above(3) = above(3) + 100;
        
        % convert the above position from task space to joint space so we
        % can input those joint values for movement
        abovePosition = robot.ik3001(above);
        
        % adjusts the base angle to the right slightly to account for math
        % error
        abovePosition(1) = abovePosition(1) - 10;
        
        % the position at which we grab the ball is the position of the
        % centroid --> convert to joint space 
        grabPosition = robot.ik3001(exactRedCenters);

        % adjusts the base angle to the right slightly to account for math
        % error
        grabPosition(1) = grabPosition(1) - 10;
        
        % start the arm at initial joint positions of zero
        robot.interpolate_jp([1000 0 0 0]);
        pause(1);
        
        % move the arm above the ball
        robot.interpolate_jp([1000 abovePosition]);
        pause(2);
        
        % move the arm to the ball
        robot.interpolate_jp([1000 grabPosition]);
        pause(2);
        
        % close the gripper to grab the ball
        robot.closeGripper();
        
        % send the arm back to the initial joint positions of zero
        robot.interpolate_jp([1000 0 0 0]);
        pause(2);
        
        % send arm to THIS position for red ball
        robot.interpolate_jp([1000 88 86 -30]);
        pause(2);
        
        % open the gripper to drop the ball
        robot.openGripper();
        pause(2);
        
        % finalize the arm position to the initial joint positions of zero
        robot.interpolate_jp([1000 0 0 0]);
        pause(2);
        
    end
    
    % repeat this process for each color 
    % program moves sequentially with if statements in a while loop
    % red --> orange --> green --> yellow --> red...
    % the program throws out an error if no centers are detected (no balls
    % on the board)
    
    % Orange Ball
    ballImage = snapshot(cam.cam);
    [bwOrange, ignore] = createOrangeMask(ballImage);
    [orangeCenters, orangeRadii] = imfindcircles(bwOrange, [20 60]);
    
    if (not(isempty(orangeCenters)))
        
        notExactOrangeCenters = getBallCenters(cam, orangeCenters);
        exactOrangeCenters = getExactCenters(cam, notExactOrangeCenters);
                
        above = exactOrangeCenters;
        above(3) = above(3) + 100;
        
        abovePosition = robot.ik3001(above);
        abovePosition(1) = abovePosition(1) - 10;
        
        grabPosition = robot.ik3001(exactOrangeCenters);
        grabPosition(1) = grabPosition(1) - 10;

        robot.interpolate_jp([1000 0 0 0]);
        pause(1);
        
        robot.interpolate_jp([1000 abovePosition]);
        pause(2);
        
        robot.interpolate_jp([1000 grabPosition]);
        pause(2);
        
        robot.closeGripper();
        
        robot.interpolate_jp([1000 0 0 0]);
        pause(2);
        
        % send arm to THIS position for orange ball
        robot.interpolate_jp([1000 58 94 -50]);
        pause(2);
        
        robot.openGripper();
        pause(2);
        
        robot.interpolate_jp([1000 0 0 0]);
        pause(2);
        
    end
    
    % Green Ball
    ballImage = snapshot(cam.cam);
    [bwGreen, ignore] = createGreenMask(ballImage);
    [greenCenters, greenRadii] = imfindcircles(bwGreen, [20 60]);
    
    if (not(isempty(orangeCenters)))

        notExactGreenCenters = getBallCenters(cam, greenCenters);
        exactGreenCenters = getExactCenters(cam, notExactGreenCenters);

        above = exactGreenCenters;
        above(3) = above(3) + 100;

        abovePosition = robot.ik3001(above);
        abovePosition(1) = abovePosition(1) - 10;

        grabPosition = robot.ik3001(exactGreenCenters);
        grabPosition(1) = grabPosition(1) - 10;

        robot.interpolate_jp([1000 0 0 0]);
        pause(1);

        robot.interpolate_jp([1000 abovePosition]);
        pause(2);

        robot.interpolate_jp([1000 grabPosition]);
        pause(2);

        robot.closeGripper();

        robot.interpolate_jp([1000 0 0 0]);
        pause(2);

        % send arm to THIS position for green ball
        robot.interpolate_jp([1000 -62 86 -38]);
        pause(2);

        robot.openGripper();
        pause(2);

        robot.interpolate_jp([1000 0 0 0]);
        pause(2);

    end
    
    % Yellow Ball
    ballImage = snapshot(cam.cam);
    [bwYellow, ignore] = createYellowMask(ballImage);
    [yellowCenters, yellowRadii] = imfindcircles(bwYellow, [20 60]);
    
    if (not(isempty(yellowCenters)))

        notExactYellowCenters = getBallCenters(cam, yellowCenters);
        exactYellowCenters = getExactCenters(cam, notExactYellowCenters);

        above = exactYellowCenters;
        above(3) = above(3) + 100;

        abovePosition = robot.ik3001(above);
        abovePosition(1) = abovePosition(1) - 10;

        grabPosition = robot.ik3001(exactYellowCenters);
        grabPosition(1) = grabPosition(1) - 10;

        robot.interpolate_jp([1000 0 0 0]);
        pause(1);

        robot.interpolate_jp([1000 abovePosition]);
        pause(2);

        robot.interpolate_jp([1000 grabPosition]);
        pause(2);

        robot.closeGripper();

        robot.interpolate_jp([1000 0 0 0]);
        pause(2);

        % send arm to THIS position for yellow ball
        robot.interpolate_jp([1000 -93 77 -14]);
        pause(2);

        robot.openGripper();
        pause(2);

        robot.interpolate_jp([1000 0 0 0]);
        pause(2);

    end    
    
    
end


catch exception
    
    fprintf('\n ERROR!!! \n \n');
    disp(getReport(exception));
    disp('Exited on error, clean shutdown');
end

%% Shutdown Procedure
robot.shutdown()
% comment out below
% cam.shutdown()


% sign-off #2 --> converts from camera space center positions of the ball to robot space
% center positions of the ball by going from camera to checkerboard to robot space
function ball_centers = getBallCenters(cam, camera_centers)

    intrinsics = cam.params.Intrinsics;
    Rcam = cam.cam_pose(1:3,1:3);
    Tcam = cam.cam_pose(1:3,4);
            
    pixelToWorld = pointsToWorld(intrinsics,Rcam,Tcam,camera_centers);
            
    RotZ = [0 1 0
            -1 0 0
            0 0 1];

    RotX = [1 0 0
            0 -1 0
            0 0 -1];

    Translation = [
                   50
                   -100
                   0
                  ];

    Rot = RotX*RotZ;

    Transformation = [Rot Translation
                        0 0 0 1];

    chessPos = [pixelToWorld(1)
                pixelToWorld(2)
                0
                1];

    ball_centers = Transformation * chessPos;
          
end


% accounts for the slight error of the ball centers in robot space from
% sign-off #2 and uses trig math to adjust for that error to get the exact
% center of the ball in robot space
function exact_centers = getExactCenters(cam, ball_centers)

    if (isempty(ball_centers))
        exact_centers = [];
        return;
    end

    Cpose = cam.cam_pose;

    distance = 50 - Cpose(1,4);

    XBase = distance - ball_centers(1,1);
    YBase = -ball_centers(2,1);

    baseDistance = sqrt(XBase^2 + YBase^2);
    circ = (11.5/2);
    baseHeight = Cpose(3,4);

    shift = ((circ*baseDistance)/(baseHeight));
    xShift = shift * (XBase / baseDistance);
    yShift = shift * (YBase / baseDistance);

    exactX = ball_centers(1,1) + xShift;
    exactY = ball_centers(2,1) + yShift;
    exactZ = circ;

    exact_centers = [exactX;exactY;exactZ];
    
end


