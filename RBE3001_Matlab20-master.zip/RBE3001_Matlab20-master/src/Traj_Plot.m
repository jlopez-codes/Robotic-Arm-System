clear
clear java
clear classes;

vid = hex2dec('16c0');
pid = hex2dec('0486');

disp (vid);
disp (pid);

javaaddpath ../lib/SimplePacketComsJavaFat-0.6.4.jar;
import edu.wpi.SimplePacketComs.*;
import edu.wpi.SimplePacketComs.device.*;
import edu.wpi.SimplePacketComs.phy.*;
import java.util.*;
import org.hid4java.*;
version -java
myHIDSimplePacketComs=HIDfactory.get();
myHIDSimplePacketComs.setPid(pid);
myHIDSimplePacketComs.setVid(vid);
myHIDSimplePacketComs.connect();

% Create a PacketProcessor object to send data to the nucleo firmware
pp = Robot(myHIDSimplePacketComs); 
model = Model(myHIDSimplePacketComs); 
traj = Traj_Planner(myHIDSimplePacketComs);

%Use IK to go from task space to joint space

%Start arm at the first position
pp.interpolate_jp([1000 pp.ik3001([55; -7; 20])]);

pause(2);

%Time values array
time = zeros(10000,1);

%Joint angles array
joint1 = zeros(10000,1);
joint2 = zeros(10000,1);
joint3 = zeros(10000,1);

%End effector position array
xpos = zeros(10000,1);
ypos = zeros(10000,1);
zpos = zeros(10000,1);

%Start the timer and store it
%initial_time = tic;
tic

%Send the arm to the second triangle position
pp.interpolate_jp([2000 pp.ik3001([72; 80; 120])]);
for i = 1:1200 %Iterate through the loop enough times to gather data while taking the 2000ms interpolation time into account
   
   %Grabs the position values
   angles = pp.measured_js(true,false); %grab the angle values

   joint1(i) = angles(1,1); %grab the relevant angle values (first row and x)
   joint2(i) = angles(1,2); %grab the relevant angle values (first row and y)
   joint3(i) = angles(1,3); %grab the relevant angle values (first row and z)
   
   velocities = pp.measured_js(false,true); %grab the velocity values
   velocity1(i) = velocities(2,1); %grab the relevant velocity values (first row and x)
   velocity2(i) = velocities(2,2); %grab the relevant velocity values (first row and y)
   velocity3(i) = velocities(2,3); %grab the relevant velocity values (first row and z)
   
   %Grabs the transformation matrix 
   pos = pp.measured_cp();
    
   xpos(i) = pos(1,4); %grab the relevant position values values (first row, fourth column, and x)
   ypos(i) = pos(2,4); %grab the relevant position values values (second row, fourth column, and y)
   zpos(i) = pos(3,4); %grab the relevant position values values (second row, fourth column, and z)
   
   %Set the time index equal to the current time
   time(i) = toc;
end

pause(3); 

%Send the arm to the third triangle position
pp.interpolate_jp([2000 pp.ik3001([100; 0; 195])]);
for i = 1201:2400
   angles = pp.measured_js(true,false);
   joint1(i) = angles(1,1);
   joint2(i) = angles(1,2);
   joint3(i) = angles(1,3);
   
   velocities = pp.measured_js(false,true); %grab the velocity values
   velocity1(i) = velocities(2,1); %grab the relevant velocity values (first row and x)
   velocity2(i) = velocities(2,2); %grab the relevant velocity values (first row and y)
   velocity3(i) = velocities(2,3); %grab the relevant velocity values (first row and z)
   
   pos = pp.measured_cp();

   xpos(i) = pos(1,4);
   ypos(i) = pos(2,4);
   zpos(i) = pos(3,4);
   
   %Set the time index equal to the current time
   time(i) = toc;
end

pause(3);

%Send the arm to the first triangle position
pp.interpolate_jp([2000 pp.ik3001([55; -7; 20])]);
for i = 2401:10000
   angles = pp.measured_js(true,false);
   joint1(i) = angles(1,1);
   joint2(i) = angles(1,2);
   joint3(i) = angles(1,3);
   
   velocities = pp.measured_js(false,true); %grab the velocity values
   velocity1(i) = velocities(2,1); %grab the relevant velocity values (first row and x)
   velocity2(i) = velocities(2,2); %grab the relevant velocity values (first row and y)
   velocity3(i) = velocities(2,3); %grab the relevant velocity values (first row and z)
   
   pos = pp.measured_cp();

   xpos(i) = pos(1,4);
   ypos(i) = pos(2,4);
   zpos(i) = pos(3,4);
   
   %Set the time index equal to the current time
   time(i) = toc;
end

%Joint Angles vs Time
figure(1)
plot(time,joint1,"-b");
hold on; 
plot(time,joint2,"-r");
plot(time,joint3,"-g");
title("Joint Angles vs Time");
xlabel("Time(ms)");
ylabel("Joint Angle(deg)");
legend("Joint 1","Joint 2","Joint 3");

%XYZ Positions vs Time
figure(2)
plot(time,xpos,"-b");
hold on;
plot(time,zpos,"-r");
plot(time,ypos,"-g");
title("X, Y, and Z Position vs Time");
xlabel("Time(ms)");
ylabel("Position(mm)");
legend("X Position","Z Position","Y Position");

%XYZ Positions (mm) vs Time
figure(3)
plot3(xpos,ypos,zpos,"-b");
title("Tip Position Plot");
xlabel("X Position (mm)");
ylabel("Y Position (mm)");
zlabel("Z Position (mm)");
legend("Tip Position");

%Velocities vs Time
figure(4)
plot(time,velocity1,"-b");
hold on; 
plot(time,velocity2,"-r");
plot(time,velocity3,"-g");
title("Velocities vs Time");
xlabel("Time(ms)");
ylabel("Velocity(deg/s)");
legend("Joint 1","Joint 2","Joint 3");

