clear
clear java
clear classes;

vid = hex2dec('16c0');
pid = hex2dec('0486');

disp (vid);
disp (pid);

javaaddpath ../lib/SimplePacketComsJavaFat-0.6.4.jar;
import edu.wpi.SimplePacketComs.*;
import edu.wpi.SimplePacketComs.device.*;
import edu.wpi.SimplePacketComs.phy.*;
import java.util.*;
import org.hid4java.*;
version -java
myHIDSimplePacketComs=HIDfactory.get();
myHIDSimplePacketComs.setPid(pid);
myHIDSimplePacketComs.setVid(vid);
myHIDSimplePacketComs.connect();

% Create a PacketProcessor object to send data to the nucleo firmware
pp = Robot(myHIDSimplePacketComs); 
model = Model(myHIDSimplePacketComs); 
traj = Traj_Planner(myHIDSimplePacketComs);

%Start arm at the first triangle position
pp.servo_jp([-7.2532 81.3235 34.4058]);

pause(2);

%Joint angles array
joint1 = zeros(10000,1);
joint2 = zeros(10000,1);
joint3 = zeros(10000,1);

%End effector position array
xpos = zeros(10000,1);
ypos = zeros(10000,1);
zpos = zeros(10000,1);

%finds the four cubic coefficients of each joint
q1 = traj.cubic_traj(0, 2, -7.2532, 48.0128, 0, 0);
q2 = traj.cubic_traj(0, 2, 81.3235, 20.4600, 0, 0);
q3 = traj.cubic_traj(0, 2, 34.4058, 22.9265, 0, 0);

offset = 0;

tic;

i = 1;

%angle data array
angles_data = zeros(1,3);

%velocity data array
velocity_data = zeros(1,3);

while toc < 2 
    
    %finds the current joint angle 
    q1_out = traj.cubic_output(toc, q1);
    q2_out = traj.cubic_output(toc, q2);
    q3_out = traj.cubic_output(toc, q3);
    
    %finds the current joint velocity
    q1_out_vel = traj.vel_cubic_output(toc,q1);
    q2_out_vel = traj.vel_cubic_output(toc,q2);
    q3_out_vel = traj.vel_cubic_output(toc,q3);
    
    %finds the current joint acceleration
    q1_out_acc = traj.acc_cubic_output(toc,q1);
    q2_out_acc = traj.acc_cubic_output(toc,q2);
    q3_out_acc = traj.acc_cubic_output(toc,q3);

    %Send the arm to the second triangle position
    pp.servo_jp([q1_out q2_out q3_out]);
    
    angles = pp.measured_js(true,false); %grab the angle values
    
    model.plot_arm(angles(1,:));

    velocities = pp.measured_js(false,true); %grab the velocity values
   
    pos = pp.measured_cp(); %grabs the transformation matrix
    
    tip_vel = pp.fdk3001([angles(1,1) angles(1,2) angles(1,3)], [velocities(2,1), velocities(2,2), velocities(2,3)]); %gets ee velocities
    
    scalar_vel = norm([tip_vel(1,1),tip_vel(2,1),tip_vel(3,1)]); %gets the magnitude of the ee velocity
    
    %store the relevant data in an array
    data = [toc angles(1,1) angles(1,2) angles(1,3) velocities(2,1) velocities(2,2) velocities(2,3) pos(1,4) pos(2,4) pos(3,4) q1_out_vel q2_out_vel q3_out_vel q1_out_acc q2_out_acc q3_out_acc tip_vel(1,1) tip_vel(2,1) tip_vel(3,1) tip_vel(4,1) tip_vel(5,1) tip_vel(6,1) scalar_vel];
    
    %write the array to a csv and append the data
    writematrix(data, 'traj.csv','WriteMode','append');

    i = i + 1;
    
end

offset = toc;

tic;

q4 = traj.cubic_traj(0, 2, 48.0128, 0, 0, 0);
q5 = traj.cubic_traj(0, 2, 20.4600, 0, 0, 0);
q6 = traj.cubic_traj(0, 2, 22.9265, 0, 0, 0);

while toc < 2
    
    q4_out = traj.cubic_output(toc, q4);
    q5_out = traj.cubic_output(toc, q5);
    q6_out = traj.cubic_output(toc, q6);
    
    q4_out_vel = traj.vel_cubic_output(toc,q4);
    q5_out_vel = traj.vel_cubic_output(toc,q5);
    q6_out_vel = traj.vel_cubic_output(toc,q6);
    
    q4_out_acc = traj.acc_cubic_output(toc,q4);
    q5_out_acc = traj.acc_cubic_output(toc,q5);
    q6_out_acc = traj.acc_cubic_output(toc,q6);

    %Send the arm to the third triangle position
    pp.servo_jp([q4_out q5_out q6_out]);
    
    angles = pp.measured_js(true,false);
    
    model.plot_arm(angles(1,:));
   
    velocities = pp.measured_js(false,true); 
    
    pos = pp.measured_cp();
    
    tip_vel = pp.fdk3001([angles(1,1) angles(1,2) angles(1,3)], [velocities(2,1), velocities(2,2), velocities(2,3)]); %gets ee velocities
    
    scalar_vel = norm([tip_vel(1,1),tip_vel(2,1),tip_vel(3,1)]); %gets the magnitude of the ee velocity
    
    data = [(toc+offset) angles(1,1) angles(1,2) angles(1,3) velocities(2,1) velocities(2,2) velocities(2,3) pos(1,4) pos(2,4) pos(3,4) q4_out_vel q5_out_vel q6_out_vel q4_out_acc q5_out_acc q6_out_acc tip_vel(1,1) tip_vel(2,1) tip_vel(3,1) tip_vel(4,1) tip_vel(5,1) tip_vel(6,1) scalar_vel];
   
    writematrix(data, 'traj.csv','WriteMode','append');

    i = i + 1;
    
end

offset = toc + offset;

tic;

q7 = traj.cubic_traj(0, 2, 0, -7.2532, 0, 0);
q8 = traj.cubic_traj(0, 2, 0, 81.3235, 0, 0);
q9 = traj.cubic_traj(0, 2, 0, 34.4058, 0, 0);

while toc < 2  
    
    q7_out = traj.cubic_output(toc, q7);
    q8_out = traj.cubic_output(toc, q8);
    q9_out = traj.cubic_output(toc, q9);
    
    q7_out_vel = traj.vel_cubic_output(toc,q7);
    q8_out_vel = traj.vel_cubic_output(toc,q8);
    q9_out_vel = traj.vel_cubic_output(toc,q9);
    
    q7_out_acc = traj.acc_cubic_output(toc,q7);
    q8_out_acc = traj.acc_cubic_output(toc,q8);
    q9_out_acc = traj.acc_cubic_output(toc,q9);

    %Send the arm to the first triangle position
    pp.servo_jp([q7_out q8_out q9_out]);
        
    angles = pp.measured_js(true,false);
    
    model.plot_arm(angles(1,:));
   
    velocities = pp.measured_js(false,true); 
  
    pos = pp.measured_cp();
    
    tip_vel = pp.fdk3001([angles(1,1) angles(1,2) angles(1,3)], [velocities(2,1), velocities(2,2), velocities(2,3)]); %gets ee velocities
    
    scalar_vel = norm([tip_vel(1,1),tip_vel(2,1),tip_vel(3,1)]); %gets the magnitude of the ee velocity

    data = [(toc+offset) angles(1,1) angles(1,2) angles(1,3) velocities(2,1) velocities(2,2) velocities(2,3) pos(1,4) pos(2,4) pos(3,4) q7_out_vel q8_out_vel q9_out_vel q7_out_acc q8_out_acc q9_out_acc tip_vel(1,1) tip_vel(2,1) tip_vel(3,1) tip_vel(4,1) tip_vel(5,1) tip_vel(6,1) scalar_vel];
    
    writematrix(data, 'traj.csv','WriteMode','append');
   
    i = i + 1;
    
end


joint_data_com = csvread('traj.csv');
time = joint_data_com(:,1);

%Tip Velocities vs Time
figure(1)
plot(time,joint_data_com(:,17));
hold on
plot(time,joint_data_com(:,18));
plot(time,joint_data_com(:,19));
title("Tip Velocities vs Time");
xlabel("Time(s)");
ylabel("Velocity(mm/s)");
legend("X","Y","Z");

%Tip Angular Velocities vs Time
figure(2)
plot(time,joint_data_com(:,20));
hold on
plot(time,joint_data_com(:,21));
plot(time,joint_data_com(:,22));
title("Tip Angular Velocities vs Time");
xlabel("Time(s)");
ylabel("Angular Velocity(rad/s)");
legend("X","Y","Z");

%Tip Scalar Velocities vs Time
figure(3)
plot(time,joint_data_com(:,23));
title("Tip Scalar Velocities vs Time");
xlabel("Time(s)");
ylabel("Scalar Velocity(mm/s)");