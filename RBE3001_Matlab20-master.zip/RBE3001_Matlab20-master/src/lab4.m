clear
clear java
clear classes;

vid = hex2dec('16c0');
pid = hex2dec('0486');

disp (vid);
disp (pid);

javaaddpath ../lib/SimplePacketComsJavaFat-0.6.4.jar;
import edu.wpi.SimplePacketComs.*;
import edu.wpi.SimplePacketComs.device.*;
import edu.wpi.SimplePacketComs.phy.*;
import java.util.*;
import org.hid4java.*;
version -java
myHIDSimplePacketComs=HIDfactory.get();
myHIDSimplePacketComs.setPid(pid);
myHIDSimplePacketComs.setVid(vid);
myHIDSimplePacketComs.connect();

% Create a PacketProcessor object to send data to the nucleo firmware
pp = Robot(myHIDSimplePacketComs); 
model = Model(myHIDSimplePacketComs); 
traj = Traj_Planner(myHIDSimplePacketComs);

tic;

q1 = traj.cubic_traj(0, 2, 100, 0, 0, 0);
q2 = traj.cubic_traj(0, 2, 0, 0, 0, 0);
q3 = traj.cubic_traj(0, 2, 195, 250, 0, 0);

% q1 = traj.cubic_traj(0, 2, 0, 0, 0, 0);
% q2 = traj.cubic_traj(0, 2, 0, 0, 0, 0);
% q3 = traj.cubic_traj(0, 2, 0, -90, 0, 0);

while toc < 3
    
    %finds the current joint angle 
    q1_out = traj.cubic_output(toc, q1);
    q2_out = traj.cubic_output(toc, q2);
    q3_out = traj.cubic_output(toc, q3);

    %Send the arm to the second triangle position
    pp.servo_jp(pp.ik3001([q1_out; q2_out; q3_out]));
%     pp.servo_jp([q1_out; q2_out; q3_out]);
    
    angles = pp.measured_js(true,false);
    
    %grabs the jacobian and the determinant and outputs it to the console
    pp.jacob3001(angles(1,:))
    pp.det3001(angles(1,:))
    
    pp.measured_js(true,false) 
    points = pp.measured_js(true,false); 
    points = points(1,:);
%     model.plot_arm(points);
    det = pp.det3001(angles(1,:));
    pos = pp.measured_cp(); %grabs the transformation matrix
    
    det_data = [toc pos(1,4) pos(2,4) pos(3,4) det];
     
    writematrix(det_data, 'det_data.csv','WriteMode','append');

end

data = csvread('det_data.csv');

%Tip Position in 3D Task Space
figure(1)
plot3(data(:,2),data(:,3),data(:,4),"-b");
title("Tip Position Plot");
xlabel("X Position (mm)");
ylabel("Y Position (mm)");
zlabel("Z Position (mm)");
legend("Tip Position");

%Determinant vs Time
figure(2)
plot(data(:,1),data(:,5));
title("Determinant vs Time");
xlabel("Time (s)");
ylabel("Determinant");