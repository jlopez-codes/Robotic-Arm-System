clear
clear java
clear classes;

vid = hex2dec('16c0');
pid = hex2dec('0486');

disp (vid);
disp (pid);

javaaddpath ../lib/SimplePacketComsJavaFat-0.6.4.jar;
import edu.wpi.SimplePacketComs.*;
import edu.wpi.SimplePacketComs.device.*;
import edu.wpi.SimplePacketComs.phy.*;
import java.util.*;
import org.hid4java.*;
version -java
myHIDSimplePacketComs=HIDfactory.get();
myHIDSimplePacketComs.setPid(pid);
myHIDSimplePacketComs.setVid(vid);
myHIDSimplePacketComs.connect();

% Create a PacketProcessor object to send data to the nucleo firmware
pp = Robot(myHIDSimplePacketComs); 
model = Model(myHIDSimplePacketComs); 
traj = Traj_Planner(myHIDSimplePacketComs);

%Use IK to go from task space to joint space

%Start arm at the first triangle position
pp.servo_jp(pp.ik3001([55; -7; 20]));

pause(2);

%Joint angles array
joint1 = zeros(10000,1);
joint2 = zeros(10000,1);
joint3 = zeros(10000,1);

%End effector position array
xpos = zeros(10000,1);
ypos = zeros(10000,1);
zpos = zeros(10000,1);

%grabs the four EE xyz positions
q1 = traj.quin_traj(0, 2, 55, 72, 0, 0, 0, 0);
q2 = traj.quin_traj(0, 2, -7, 80, 0, 0, 0, 0);
q3 = traj.quin_traj(0, 2, 20, 120, 0, 0, 0, 0);

offset = 0;

tic;

i = 1;

%angle data array
angles_data = zeros(1,3);

%velocity data array
velocity_data = zeros(1,3);

while toc < 2 
   
    %grabs the current EE xyz position, respectively
    q1_out = traj.quin_output(toc, q1);
    q2_out = traj.quin_output(toc, q2);
    q3_out = traj.quin_output(toc, q3);
    
    %grabs the current EE xyz velocities, respectively
    q1_out_vel = traj.vel_quin_output(toc,q1);
    q2_out_vel = traj.vel_quin_output(toc,q2);
    q3_out_vel = traj.vel_quin_output(toc,q3);
    
    %grabs the current EE xyz accelerations, respectively
    q1_out_acc = traj.acc_quin_output(toc,q1);
    q2_out_acc = traj.acc_quin_output(toc,q2);
    q3_out_acc = traj.acc_quin_output(toc,q3);

    %send the arm to the second triangle position
    pp.servo_jp(pp.ik3001([q1_out; q2_out; q3_out]));
    
    angles = pp.measured_js(true,false); %grab the angle values

    velocities = pp.measured_js(false,true); %grab the velocity values
   
    pos = pp.measured_cp(); %grabs the transformation matrix
    
    %store the relevant data in an array
    data = [toc angles(1,1) angles(1,2) angles(1,3) velocities(2,1) velocities(2,2) velocities(2,3) pos(1,4) pos(2,4) pos(3,4) q1_out_vel q2_out_vel q3_out_vel q1_out_acc q2_out_acc q3_out_acc];
    
    %write the array to a csv and append the data
    writematrix(data, 'traj.csv','WriteMode','append');

    i = i + 1;
    
end

offset = toc;

tic;

q4 = traj.quin_traj(0, 2, 72, 100, 0, 0, 0, 0);
q5 = traj.quin_traj(0, 2, 80, 0, 0, 0, 0, 0);
q6 = traj.quin_traj(0, 2, 120, 195, 0, 0, 0, 0);

while toc < 2
    
    q4_out = traj.quin_output(toc, q4);
    q5_out = traj.quin_output(toc, q5);
    q6_out = traj.quin_output(toc, q6);
    
    q4_out_vel = traj.vel_quin_output(toc,q4);
    q5_out_vel = traj.vel_quin_output(toc,q5);
    q6_out_vel = traj.vel_quin_output(toc,q6);
    
    q4_out_acc = traj.acc_quin_output(toc,q4);
    q5_out_acc = traj.acc_quin_output(toc,q5);
    q6_out_acc = traj.acc_quin_output(toc,q6);

    %Send the arm to the third triangle position
    pp.servo_jp(pp.ik3001([q4_out; q5_out; q6_out]));
    
    angles = pp.measured_js(true,false);
   
    velocities = pp.measured_js(false,true); 
    
    pos = pp.measured_cp();
    
    data = [(toc+offset) angles(1,1) angles(1,2) angles(1,3) velocities(2,1) velocities(2,2) velocities(2,3) pos(1,4) pos(2,4) pos(3,4) q4_out_vel q5_out_vel q6_out_vel q4_out_acc q5_out_acc q6_out_acc];
   
    writematrix(data, 'traj.csv','WriteMode','append');

    i = i + 1;
    
end

offset = toc + offset;

tic;

q7 = traj.quin_traj(0, 2, 100, 55, 0, 0, 0, 0);
q8 = traj.quin_traj(0, 2, 0, -7, 0, 0, 0, 0);
q9 = traj.quin_traj(0, 2, 195, 20, 0, 0, 0, 0);

while toc < 2  
    
    q7_out = traj.quin_output(toc, q7);
    q8_out = traj.quin_output(toc, q8);
    q9_out = traj.quin_output(toc, q9);
    
    q7_out_vel = traj.vel_quin_output(toc,q7);
    q8_out_vel = traj.vel_quin_output(toc,q8);
    q9_out_vel = traj.vel_quin_output(toc,q9);
    
    q7_out_acc = traj.acc_quin_output(toc,q7);
    q8_out_acc = traj.acc_quin_output(toc,q8);
    q9_out_acc = traj.acc_quin_output(toc,q9);

    %Send the arm to the first triangle position
    pp.servo_jp(pp.ik3001([q7_out; q8_out; q9_out]));
        
    angles = pp.measured_js(true,false);
   
    velocities = pp.measured_js(false,true); 
  
    pos = pp.measured_cp();

    data = [(toc+offset) angles(1,1) angles(1,2) angles(1,3) velocities(2,1) velocities(2,2) velocities(2,3) pos(1,4) pos(2,4) pos(3,4) q7_out_vel q8_out_vel q9_out_vel q7_out_acc q8_out_acc q9_out_acc];
    
    writematrix(data, 'traj.csv','WriteMode','append');
   
    i = i + 1;
    
end


joint_data_com = csvread('traj.csv');
time = joint_data_com(:,1);

figure(1)
plot(time,joint_data_com(:,2),"-b");
hold on; 
plot(time,joint_data_com(:,3),"-r");
plot(time,joint_data_com(:,4),"-g");
title("Joint Angles vs Time");
xlabel("Time(s)");
ylabel("Joint Angle(deg)");
legend("Joint 1","Joint 2","Joint 3");

figure(2)
plot(time,joint_data_com(:,8),"-b");
hold on;
plot(time,joint_data_com(:,9),"-r");
plot(time,joint_data_com(:,10),"-g");
title("X, Y, and Z Position vs Time");
xlabel("Time(s)");  
ylabel("Position(mm)");
legend("X Position","Y Position","Z Position");

figure(3)
plot3(joint_data_com(:,8),joint_data_com(:,9),joint_data_com(:,10),"-b");
title("Tip Position Plot");
xlabel("X Position (mm)");
ylabel("Y Position (mm)");
zlabel("Z Position (mm)");
legend("Tip Position");

figure(4)
plot(time,joint_data_com(:,5),"-b");
hold on; 
plot(time,joint_data_com(:,6),"-r");
plot(time,joint_data_com(:,7),"-g");
title("Velocities vs Time");
xlabel("Time(s)");
ylabel("Velocity(deg/s)");
legend("Joint 1","Joint 2","Joint 3");

figure(5)
plot(time,joint_data_com(:,11));
hold on
plot(time,joint_data_com(:,12));
plot(time,joint_data_com(:,13));
title("Velocities vs Time");
xlabel("Time(s)");
ylabel("Velocity(mm/s)");
legend("Joint 1","Joint 2","Joint 3");

figure(6)
plot(time,joint_data_com(:,14));
hold on
plot(time,joint_data_com(:,15));
plot(time,joint_data_com(:,16));
title("Acceleration vs Time");
xlabel("Time(s)");
ylabel("Acceleration(mm/s^2)");
legend("Joint 1","Joint 2","Joint 3");