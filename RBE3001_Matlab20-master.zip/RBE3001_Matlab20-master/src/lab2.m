clear
clear java
clear classes;

vid = hex2dec('16c0');
pid = hex2dec('0486');

disp (vid);
disp (pid);

javaaddpath ../lib/SimplePacketComsJavaFat-0.6.4.jar;
import edu.wpi.SimplePacketComs.*;
import edu.wpi.SimplePacketComs.device.*;
import edu.wpi.SimplePacketComs.phy.*;
import java.util.*;
import org.hid4java.*;
version -java
myHIDSimplePacketComs=HIDfactory.get();
myHIDSimplePacketComs.setPid(pid);
myHIDSimplePacketComs.setVid(vid);
myHIDSimplePacketComs.connect();

% Create a PacketProcessor object to send data to the nucleo firmware
pp = Robot(myHIDSimplePacketComs); 

pp.fk3001([0 0 0]);

position = zeros(10, 4, 'single');    
pp.servo_jp([0 0 0]);

%Part 5 --> sends the arm to position [45 45 45] back to [0 0 0] ten times
for i = 1:10
    
    pp.servo_jp([45 45 45]);
    pause(3);
    pp.servo_jp([0 0 0]);
    pause(3);
    
    pp.measured_js(true,false);
    pp.measured_cp()
    
    %Gets the position values and stores the first row (actual positions)
    newMatrix = pp.measured_cp();
    positionMatrix = transpose(newMatrix);    
    position(i, :) = positionMatrix(4,:);           
    
end

writematrix(position,"lab2_plot1.csv")  
Array=csvread('lab2_plot1.csv');

%Finds the mean of the positions
mean = mean(Array)

%Plots the individual position points on a graph with unique colors
plot3(Array(1),Array(2),Array(3),"r*",Array(4),Array(5),Array(6),"m*",Array(7),Array(8),Array(9),"c*",Array(10),Array(11),Array(12),"g*",Array(13),Array(14),Array(15),"b*",Array(16),Array(17),Array(18),"r*",Array(19),Array(20),Array(21),"m*",Array(22),Array(23),Array(24),"c*",Array(25),Array(26),Array(27),"g*",Array(28),Array(29),Array(30),"b*");
title("Arm Tip Position")                      
ylabel("Y Angle (deg)")                 
xlabel("X Angle (deg)")                   
zlabel("Z Angle (deg)")

