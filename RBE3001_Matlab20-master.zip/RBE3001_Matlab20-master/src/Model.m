classdef Model < handle
    
    properties
        myHIDSimplePacketComs;
        pol;
        robot
    end
    
    methods
        
        function mod = Model(dev)
            mod.myHIDSimplePacketComs=dev;
            mod.pol = java.lang.Boolean(false);
            mod.robot = Robot(mod.myHIDSimplePacketComs);
        end
        
        %Takes in joint values and plots a stick model of the arm 
        function plot_arm(model,q)
            FK=model.robot.DHkine(q);
            
            T01 = FK(1:4,1:4);
            T02 = FK(1:4,5:8);
            T03 = FK(1:4,9:12);
            T04 = FK(1:4,13:16);
            
            angles = model.robot.measured_js(true,false); %grab the angle values

            velocities = model.robot.measured_js(false,true); %grab the velocity values
            
            %if the velocities are negligible, set them to be read as zero
            %to avoid for unwanted noise when drawing up the velocity
            %vector
            if abs(velocities(2,1))<5
                velocities(2,1) = 0;
            end
            
            if abs(velocities(2,2))<5
                velocities(2,2) = 0;
            end
            
            if abs(velocities(2,3))<5
                velocities(2,3) = 0;
            end
            
            tip_vel = model.robot.fdk3001([angles(1,1) angles(1,2) angles(1,3)], [velocities(2,1), velocities(2,2), velocities(2,3)]);
            
            Q = model.robot.XYZkine(FK);
            figure(1)
            plot3(Q(1,:),Q(2,:),Q(3,:),"r-o")
            hold on
            model.plot_ref(T01)
            model.plot_ref(T02)
            model.plot_ref(T03)
            model.plot_ref(T04)
            
            %plots the velocity vector of the arm on the end effector 
            quiver3(T04(1,4),T04(2,4),T04(3,4),log(abs(tip_vel(1,1)))*(tip_vel(1,1)/abs(tip_vel(1,1)))*5,log(abs(tip_vel(2,1)))*(tip_vel(2,1)/abs(tip_vel(2,1)))*5,log(abs(tip_vel(3,1)))*(tip_vel(3,1)/abs(tip_vel(3,1)))*5)
            
            hold off
            xlim([-300 300])
            ylim([-300 300])
            zlim([0 400])
            xlabel('X distance (mm)')
            ylabel('Y distance (mm)')
            zlabel('Z distance (mm)')
            grid on
            
        end
        
        %Creates reference frames for the stick model
        function plot_ref(model,r)
            x = r(1:3,1);
            x = transpose(x);
            y = r(1:3,2);
            y = transpose(y);
            z = r(1:3,3);
            z = transpose(z);
            origin = r(1:3,4);
            origin = transpose(origin);
            
            length = 40;
            
            %Creates x,y,z line matrices at the origin to an assigned
            %length
            x_line = [origin;(x*length)+origin];
            y_line = [origin;(y*length)+origin];
            z_line = [origin;(z*length)+origin];
            
            %Plots the lines at the x,y,z axes in the direction of the unit
            %vector
            plot3(x_line(:,1), x_line(:,2), x_line(:,3), "b");
            plot3(y_line(:,1), y_line(:,2), y_line(:,3), "b");
            plot3(z_line(:,1), z_line(:,2), z_line(:,3), "b");
            
        end

    end
    
end


