clear
clear java
clear classes;

vid = hex2dec('16c0');
pid = hex2dec('0486');

disp (vid);
disp (pid);

javaaddpath ../lib/SimplePacketComsJavaFat-0.6.4.jar;
import edu.wpi.SimplePacketComs.*;
import edu.wpi.SimplePacketComs.device.*;
import edu.wpi.SimplePacketComs.phy.*;
import java.util.*;
import org.hid4java.*;
version -java
myHIDSimplePacketComs=HIDfactory.get();
myHIDSimplePacketComs.setPid(pid);
myHIDSimplePacketComs.setVid(vid);
myHIDSimplePacketComs.connect();

% Create a PacketProcessor object to send data to the nucleo firmware
pp = Robot(myHIDSimplePacketComs); 

position = zeros(9000, 3, 'single');    %creates a 9000x3 matrix of zeroes representing position values
time = zeros(9000, 1, 'single');        %creates a 9000x1 matrix of zeroes representing time values

pp.servo_jp([0,0,0]);                   %sets arm to the zero position

pause(3);                               %wait for 3 seconds to acquire accurate data

timeMatrix = [0];                       %creates a matrix of zeroes
tic                                     %starts the timer

%Comment out configurations not currently being tested

%Configuration 1
%pp.interpolate_jp([2500, -33.1200, 83.0200, -52.2100]);     %with interpolation time
%pp.servo_jp([-33.1200, 83.0200, -52.2100]);                 %without interpolation time

%Configuration 2
%pp.interpolate_jp([2500, -2.4000, 72.2200, -54.3700]);     %with interpolation time
%pp.servo_jp([-2.4000, 72.2200, -54.3700]);                 %without interpolation time

%Configuration 3
%pp.interpolate_jp([2500, 22.0800, 82.0600, -39.4900]);     %with interpolation time
%pp.servo_jp([22.0800, 82.0600, -39.4900]);                 %without interpolation time

%Configuration 4
%pp.interpolate_jp([2500, 63.6000, 68.3800, -41.6500]);     %with interpolation time
pp.servo_jp([63.6000, 68.3800, -41.6500]);                 %without interpolation time

for i = 1:9000      %iterate through a loop 9000 times
   
    positionMatrix = pp.measured_js(true,false);    %set a position matrix equal to the current joint position measurements
    position(i, :) = positionMatrix(1,:);           %grab only the top row (of position values) and insert it into the iterated row to fill the matrix with position values
    time(i, :) = timeMatrix;                        %set the iterated row of the time matrix equal to the matrix that will collect the time stamps
    timeMatrix = toc;                               %have the matrix of time values collect the timestamp in ms
    
end

position = [position,time];                     %concatenate the position values matrix with the time values matrix by column                         
writematrix(position,"configurations.csv")      %send the new matrix into a .csv file

position = [position,time];             %concatenate the position values matrix with the time values matrix by column                         
writematrix(position,"results.csv")     %send the new matrix into a .csv file

Array=csvread('results.csv');           %throws the .csv file into a new variable 'Array'
hold on                                 %allows us to plot multiple lines on the figure
colTime = Array(:, 4);                  %grabs time data
col1 = Array(:, 1);                     %grabs position joint 1 data
col2 = Array(:, 2);                     %grabs position joint 2 data
col3 = Array(:, 3);                     %grabs position joint 3 data
figure(1)                               %ensures the following graph gets labeled as Figure 1

plot(colTime, col1)                     %plots joint 1 data with respect to time
plot(colTime, col2)                     %plots joint 2 data with respect to time
plot(colTime, col3)                     %plots joint 3 data with respect to time
title("Motor Angle vs Time")            %makes the title             
legend("Motor 1", "Motor 2", "Motor 3");%makes the legend
ylabel("Angle (deg)")                   %labels the y-axis
xlabel("Time (sec)")                    %labels the x-axis
hold off                                %makes sure the next set of data won't be plotted on Figure 1
figure(2)                               %ensures the following graph gets labeled as Figure 2
histogram(colTime)                      %generates a histogram based on timing data
title("Timesteps")                      %makes a title
legend("Timesteps");                    %makes a legend       
ylabel("Frequency")                     %labels the y-axis
xlabel("Time(ms)")                      %labels the x-axis

