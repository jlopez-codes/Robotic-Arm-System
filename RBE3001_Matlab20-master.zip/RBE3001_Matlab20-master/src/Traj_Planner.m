classdef Traj_Planner < handle
    
    properties
        myHIDSimplePacketComs;
        pol;
        traj_array;
    end
    
    methods
        
        function traj = Traj_Planner(dev)
            traj.myHIDSimplePacketComs=dev;
            traj.pol = java.lang.Boolean(false);
        end
        

        %takes in t0, tf, q0, qf, v0, vf in that order 
        %returns the four coefficients used to solve the cubic function
        function traj_array = cubic_traj(traj, t0, tf, q0, qf, v0, vf)  
            cubicMatrix = [1 t0 (t0)^2 (t0)^3; 0 1 2*(t0) 3*((t0)^2); 1 tf ((tf)^2) ((tf)^3); 0 1 2*(tf) 3*((tf)^2)];
            cubicGiven = [ q0; v0; qf; vf];
            col_traj_array = (inv(cubicMatrix))*(cubicGiven);
            traj_array = transpose(col_traj_array); %transposes matrix to simplify matrix math
        end
        
        %takes in time and the four coefficients from cubic_traj
        %outputs the EE position (x, y, or z) or joint angle (theta1,
        %theta2, theta3) --> singular number
        function q = cubic_output(traj, time, coefficients)
            a0 = coefficients(1);
            a1 = coefficients(2);
            a2 = coefficients(3);
            a3 = coefficients(4);
            q = a0 + (a1*time) + (a2*((time)^2)) + (a3*((time)^3));
        end
        
        %takes in time and the four coefficients from cubic_traj
        %outputs the velocity (task space or joint space) by taking the
        %derivative of the previous function --> singular number
        function vel_q = vel_cubic_output(traj, time, coefficients)
            a1 = coefficients(2);
            a2 = coefficients(3);
            a3 = coefficients(4);
            vel_q = a1 + (2*a2*time) + (3*a3*((time)^2));
        end
        
        %takes in time and the four coefficients from cubic_traj
        %outputs the acceleration (task space or joint space) by taking the
        %derivative of the previous function --> singular number
        function acc_q = acc_cubic_output(traj, time, coefficients)
            a2 = coefficients(3);
            a3 = coefficients(4);
            acc_q = (2*a2) + (6*a3*time);
        end
       
        %takes in t0, tf, q0, qf, v0, vf, acc0, accf in that order 
        %returns the four coefficients used to solve the quintic function
        function traj_array = quin_traj(traj,t0, tf, q0, qf, v0, vf, acc0, accf)
            quinMatrix = [1 t0 t0^2 t0^3 t0^4 t0^5; 0 1 2*t0 3*t0^2 4*t0^3 5*t0^4; 0 0 2 6*t0 12*t0^2 20*t0^3; 1 tf tf^2 tf^3 tf^4 tf^5; 0 1 2*tf 3*tf^2 4*tf^3 5*tf^4; 0 0 2 6*tf 12*tf^2 20*tf^3];
            quinGiven = [q0; v0; acc0; qf; vf; accf];
            col_traj_array = (inv(quinMatrix))*(quinGiven);
            traj_array = transpose(col_traj_array);
        end  
         
        %takes in time and the four coefficients from quintic_traj
        %outputs the EE position (x, y, or z) or joint angle (theta1,
        %theta2, theta3) --> singular number
        function q = quin_output(traj, time, coefficients)
            a0 = coefficients(1);
            a1 = coefficients(2);
            a2 = coefficients(3);
            a3 = coefficients(4);
            a4 = coefficients(5);
            a5 = coefficients(6);
            q = a0 + (a1*time) + (a2*((time)^2)) + (a3*((time)^3)) + (a4*((time)^4)) + (a5*((time)^5));
        end
        
        %takes in time and the four coefficients from quintic_traj
        %outputs the velocity (task space or joint space) by taking the
        %derivative of the previous function --> singular number
        function vel_q = vel_quin_output(traj, time, coefficients)
            a1 = coefficients(2);
            a2 = coefficients(3);
            a3 = coefficients(4);
            a4 = coefficients(5);
            a5 = coefficients(6);
            vel_q = a1 + (2*a2*time) + (3*a3*((time)^2)) + (4*a4*((time)^3)) + (5*a5*((time)^4));
        end
        
                
        %takes in time and the four coefficients from quintic_traj
        %outputs the acceleration (task space or joint space) by taking the
        %derivative of the previous function --> singular number
        function acc_q = acc_quin_output(traj, time, coefficients)
            a2 = coefficients(3);
            a3 = coefficients(4);
            a4 = coefficients(5);
            a5 = coefficients(6);
            acc_q = (2*a2) + (6*a3*time) + (12*a4*((time)^2)) + (20*a5*((time)^3));
        end
       
        %takes in the maximum amount of inputted variables and a boolean
        %that allows the user to select between running cubic_traj or
        %quintic_traj
        function coefficients = linear_traj(traj, selection, t0, tf, q0, qf, v0, vf, acc0, accf) %true OR 1 for cubic_traj and false OR 0 for quintic_traj
            if selection == 1
                coefficients = traj.cubic_traj(t0, tf, q0, qf, v0, vf);  
            else
                coefficients = traj.quin_traj(t0, tf, q0, qf, v0, vf, acc0, accf);
            end
        end
        
        %the selection input allows the user to find the EE position/joint
        %angle from either cubic_output or quin_output and takes in time
        %and the four coefficients
        function pos_output = linear_traj_pos(traj, selection, time, coefficients)
            if selection == 1
                pos_output = traj.cubic_output(time, coefficients);
            else
                pos_output = traj.quin_output(time, coefficients);
            end    
        end
        
        %the selection input allows the user to find the velocity from
        %either vel_cubic_output or vel_quin_output and takes in time and
        %the four coefficients
        function vel_output = linear_traj_vel(traj, selection, time, coefficients)
            if selection == 1
                vel_output = traj.vel_cubic_output(time, coefficients);
            else
                vel_output = traj.vel_quin_output(time, coefficients);
            end  
        end
        
        %the selection input allows the user to find the acceleration from
        %either acc_cubic_output or vel_quin_output and takes in time and
        %the four coefficients
        function acc_output = linear_traj_acc(traj, selection, time, coefficients)
            if selection == 1
                acc_output = traj.acc_cubic_output(time, coefficients);
            else
                acc_output = traj.acc_quin_output(time, coefficients);
            end
        end
  
    end
     
end


